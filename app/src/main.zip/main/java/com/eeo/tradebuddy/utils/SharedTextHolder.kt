package com.eeo.tradebuddy.utils

object SharedTextHolder {
    var sharedText: String? = null
}