package com.eeo.tradebuddy.model

data class UploadResult(
    val message: String
)
