package com.eeo.tradebuddy.ui.navigation

object NavRoutes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val ANALYZE = "analyze"
    const val REPORT = "report"
    const val PREMIUM = "premium"
    const val KAKAO_GUIDE = "kakao_guide"
    const val WAIT_FOR_SAHTE ="waitForShare"
}
